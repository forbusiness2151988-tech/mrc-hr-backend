// Creates the very first Super Admin account (with a linked Employee profile
// so the mobile app has something to show immediately) so you can log in and
// then use POST /api/auth/register (as that admin) to create everyone else.
require("dotenv").config();
const bcrypt = require("bcryptjs");
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

async function main() {
  const email = "admin@company.com";
  const password = "Admin@12345"; // change immediately after first login

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log("Admin already exists:", email);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: {
      fullName: "System Admin",
      email,
      passwordHash,
      role: "SUPER_ADMIN",
    },
  });

  await prisma.employee.create({
    data: {
      userId: user.id,
      employeeCode: "EMP-0001",
      fullName: "System Admin",
      jobTitle: "System Administrator",
      joiningDate: new Date(),
      baseSalary: 0,
      status: "ACTIVE",
    },
  });

  console.log("✅ Super Admin + Employee profile created");
  console.log("   email:   ", email);
  console.log("   password:", password);
  console.log("   ⚠️  Change this password immediately after first login.");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
