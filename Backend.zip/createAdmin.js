require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('123456', 10);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@mrc.com' },
    update: {
      passwordHash: hashedPassword,
      role: 'SUPER_ADMIN',
    },
    create: {
      fullName: 'Admin User',
      email: 'admin@mrc.com',
      passwordHash: hashedPassword,
      role: 'SUPER_ADMIN',
    },
  });

  console.log('-----------------------------------');
  console.log('✅ تم إنشاء/تحديث حساب الأدمن بنجاح!');
  console.log('Email:', admin.email);
  console.log('Password: 123456');
  console.log('Role:', admin.role);
  console.log('-----------------------------------');
}

main()
  .catch((e) => {
    console.error('❌ خطأ:', e.message);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });