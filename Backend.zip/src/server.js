require("dotenv").config();
const express = require("express");
const cors = require("cors");

const { errorHandler } = require("./middleware/errorHandler");
const authRoutes = require("./modules/auth/auth.routes");
const employeesRoutes = require("./modules/hr/employees.routes");
const attendanceRoutes = require("./modules/hr/attendance.routes");
const officesRoutes = require("./modules/hr/offices.routes");
const leavesRoutes = require("./modules/hr/leaves.routes");
const permissionsRoutes = require("./modules/hr/permissions.routes");
const payrollRoutes = require("./modules/hr/payroll.routes");
const holidaysRoutes = require("./modules/hr/holidays.routes");
const settingsRoutes = require("./modules/hr/settings.routes");

const app = express();

app.use(cors({ origin: (process.env.CORS_ORIGIN || "*").split(",") }));
app.use(express.json({ limit: "5mb" }));

// Health check — useful for free-tier hosts (Render/Railway) that ping to keep the service awake
app.get("/api/health", (req, res) => res.json({ status: "ok", app: "MRC HR", time: new Date().toISOString() }));

app.use("/api/auth", authRoutes);
app.use("/api/employees", employeesRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/offices", officesRoutes);
app.use("/api/leaves", leavesRoutes);
app.use("/api/permissions", permissionsRoutes);
app.use("/api/payroll", payrollRoutes);
app.use("/api/holidays", holidaysRoutes);
app.use("/api/settings", settingsRoutes);

app.use((req, res) => res.status(404).json({ error: "Route not found" }));
app.use(errorHandler);

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`✅ MRC HR server running on http://localhost:${PORT}`);
});
