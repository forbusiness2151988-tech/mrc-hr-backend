const express = require("express");
const { listPermissions, createPermission, updatePermissionStatus } = require("./permissions.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();
router.use(authenticate);

router.get("/", authorize("SUPER_ADMIN", "HR_MANAGER"), listPermissions);
router.post("/", createPermission); // any logged-in employee can request a permission
router.patch("/:id", authorize("SUPER_ADMIN", "HR_MANAGER"), updatePermissionStatus);

module.exports = router;
