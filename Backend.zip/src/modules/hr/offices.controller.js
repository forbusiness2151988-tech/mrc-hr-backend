const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");

const listOffices = asyncHandler(async (req, res) => {
  const offices = await prisma.office.findMany({
    include: { _count: { select: { employees: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json(offices);
});

const createOffice = asyncHandler(async (req, res) => {
  const { name, address, latitude, longitude, radiusMeters } = req.body;
  if (!name || latitude === undefined || longitude === undefined) {
    return res.status(400).json({ error: "Office name, latitude and longitude are required" });
  }

  const office = await prisma.office.create({
    data: {
      name,
      address,
      latitude: Number(latitude),
      longitude: Number(longitude),
      radiusMeters: radiusMeters ? Number(radiusMeters) : 50,
    },
  });
  res.status(201).json(office);
});

const updateOffice = asyncHandler(async (req, res) => {
  const { name, address, latitude, longitude, radiusMeters } = req.body;
  const office = await prisma.office.update({
    where: { id: req.params.id },
    data: {
      ...(name !== undefined && { name }),
      ...(address !== undefined && { address }),
      ...(latitude !== undefined && { latitude: Number(latitude) }),
      ...(longitude !== undefined && { longitude: Number(longitude) }),
      ...(radiusMeters !== undefined && { radiusMeters: Number(radiusMeters) }),
    },
  });
  res.json(office);
});

const deleteOffice = asyncHandler(async (req, res) => {
  await prisma.office.delete({ where: { id: req.params.id } });
  res.status(204).send();
});

module.exports = { listOffices, createOffice, updateOffice, deleteOffice };
