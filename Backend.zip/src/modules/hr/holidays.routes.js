const express = require("express");
const { listHolidays, createHoliday, deleteHoliday } = require("./holidays.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();
router.use(authenticate);

router.get("/", authorize("SUPER_ADMIN", "HR_MANAGER", "ACCOUNTANT"), listHolidays);
router.post("/", authorize("SUPER_ADMIN", "HR_MANAGER"), createHoliday);
router.delete("/:id", authorize("SUPER_ADMIN", "HR_MANAGER"), deleteHoliday);

module.exports = router;
