const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");

function eachDate(start, end) {
  const days = [];
  let cur = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate()));
  const last = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate()));
  while (cur <= last) {
    days.push(new Date(cur));
    cur.setUTCDate(cur.getUTCDate() + 1);
  }
  return days;
}

// Marks every active employee as HOLIDAY (no check-in required, no deduction) for each day.
// Does not overwrite a day that's already an approved leave/paid-leave/present record's checkIn data —
// it only sets status, so manual attendance already recorded for that day stays intact where relevant.
async function markEmployeesOnHoliday(startDate, endDate) {
  const employees = await prisma.employee.findMany({ where: { status: "ACTIVE" }, select: { id: true } });
  const days = eachDate(startDate, endDate);

  for (const employee of employees) {
    for (const date of days) {
      await prisma.attendance.upsert({
        where: { employeeId_date: { employeeId: employee.id, date } },
        update: { status: "HOLIDAY" },
        create: { employeeId: employee.id, date, status: "HOLIDAY", source: "MANUAL" },
      });
    }
  }
}

// GET /api/holidays?year=2026
const listHolidays = asyncHandler(async (req, res) => {
  const { year } = req.query;
  const holidays = await prisma.holiday.findMany({
    where: year
      ? {
          startDate: {
            gte: new Date(Date.UTC(Number(year), 0, 1)),
            lte: new Date(Date.UTC(Number(year), 11, 31, 23, 59, 59)),
          },
        }
      : undefined,
    orderBy: { startDate: "asc" },
  });
  res.json(holidays);
});

// POST /api/holidays  { name, startDate, endDate, notes? }
// Also fans out an attendance HOLIDAY status to every active employee for the range,
// so they're automatically paid without needing to check-in/out.
const createHoliday = asyncHandler(async (req, res) => {
  const { name, startDate, endDate, notes } = req.body;
  if (!name || !startDate) {
    return res.status(400).json({ error: "Holiday name and start date are required" });
  }

  const start = new Date(startDate);
  const end = endDate ? new Date(endDate) : start;

  const holiday = await prisma.holiday.create({
    data: { name, startDate: start, endDate: end, notes },
  });

  await markEmployeesOnHoliday(start, end);

  res.status(201).json(holiday);
});

const deleteHoliday = asyncHandler(async (req, res) => {
  await prisma.holiday.delete({ where: { id: req.params.id } });
  res.status(204).send();
});

module.exports = { listHolidays, createHoliday, deleteHoliday, markEmployeesOnHoliday };
