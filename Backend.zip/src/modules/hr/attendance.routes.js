const express = require("express");
const {
  listAttendance,
  checkIn,
  checkOut,
  bulkImport,
  monthlySummary,
  markPaidLeave,
} = require("./attendance.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();

// Any logged-in user can check in/out for themself or an employee (if they have HR access)
router.use(authenticate);

router.get("/", authorize("SUPER_ADMIN", "HR_MANAGER"), listAttendance);
router.get("/summary", authorize("SUPER_ADMIN", "HR_MANAGER"), monthlySummary);
router.post("/check-in", checkIn);
router.post("/check-out", checkOut);
router.post("/bulk-import", authorize("SUPER_ADMIN", "HR_MANAGER"), bulkImport);
router.post("/mark-paid-leave", authorize("SUPER_ADMIN", "HR_MANAGER"), markPaidLeave);

module.exports = router;
