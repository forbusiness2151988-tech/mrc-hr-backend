const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");
const {
  getWorkingDaysInMonth,
  getDailyRate,
  getHourlyRate,
  resolveShift,
  getWeekendDays,
  monthRange,
  OVERTIME_RATE_MULTIPLIER,
} = require("../../utils/payrollCalc");

const listPayrolls = asyncHandler(async (req, res) => {
  const { employeeId, month, status } = req.query;

  const payrolls = await prisma.payroll.findMany({
    where: {
      ...(employeeId && { employeeId }),
      ...(month && { month }),
      ...(status && { status }),
    },
    include: { employee: { select: { id: true, fullName: true, jobTitle: true } } },
    orderBy: [{ month: "desc" }, { createdAt: "desc" }],
  });

  res.json(payrolls);
});

// Sum of items in [{label, amount}] arrays, used for allowanceItems/deductionItems
function sumItems(items) {
  if (!Array.isArray(items)) return 0;
  return items.reduce((sum, i) => sum + Number(i.amount || 0), 0);
}

async function getCompanySettings() {
  let settings = await prisma.companySettings.findFirst();
  if (!settings) settings = await prisma.companySettings.create({ data: {} });
  return settings;
}

function permissionHoursOf(permission) {
  const [fh, fm] = permission.fromTime.split(":").map(Number);
  const [th, tm] = permission.toTime.split(":").map(Number);
  const mins = (th * 60 + tm) - (fh * 60 + fm);
  return mins > 0 ? mins / 60 : 0;
}

function round2(n) {
  return Math.round(Number(n) * 100) / 100;
}

// Computes the attendance-driven part of a payroll: working days, daily/hourly rate,
// absence deduction, permission-hours deduction and overtime pay for one employee/month.
async function computeAttendanceComponents(employee, month, settings) {
  const weekendDays = getWeekendDays(settings);
  const workingDays = getWorkingDaysInMonth(month, weekendDays);
  const dailyRate = getDailyRate(employee.baseSalary, workingDays);
  const shift = resolveShift(employee, settings);
  const hourlyRate = getHourlyRate(dailyRate, shift.hours);

  const { start, end } = monthRange(month);

  const attendance = await prisma.attendance.findMany({
    where: { employeeId: employee.id, date: { gte: start, lte: end } },
  });
  const approvedPermissions = await prisma.permission.findMany({
    where: { employeeId: employee.id, status: "APPROVED", date: { gte: start, lte: end } },
  });

  const absenceDays = attendance.filter((a) => a.status === "ABSENT").length;
  const overtimeMins = attendance.reduce((sum, a) => sum + (a.overtimeMins || 0), 0);
  const overtimeHours = overtimeMins / 60;
  const permissionHours = approvedPermissions.reduce((sum, p) => sum + permissionHoursOf(p), 0);

  const absenceDeduction = absenceDays * dailyRate;
  const permissionDeduction = permissionHours * hourlyRate;
  const overtimePay = overtimeHours * hourlyRate * OVERTIME_RATE_MULTIPLIER;

  const deductionItems = [];
  if (absenceDays > 0) {
    deductionItems.push({ label: `Absence (${absenceDays} day${absenceDays > 1 ? "s" : ""})`, amount: round2(absenceDeduction) });
  }
  if (permissionHours > 0) {
    deductionItems.push({ label: `Permission hours (${round2(permissionHours)}h)`, amount: round2(permissionDeduction) });
  }

  return {
    workingDays,
    dailyRate: round2(dailyRate),
    absenceDays,
    permissionHours: round2(permissionHours),
    overtimeHours: round2(overtimeHours),
    overtimePay: round2(overtimePay),
    deductions: round2(absenceDeduction + permissionDeduction),
    deductionItems,
  };
}

const createPayroll = asyncHandler(async (req, res) => {
  const { employeeId, month, baseSalary, allowanceItems, deductionItems, bonus, overtimePay, notes } = req.body;
  if (!employeeId || !month || baseSalary === undefined) {
    return res.status(400).json({ error: "Employee, month and base salary are required" });
  }

  const allowances = sumItems(allowanceItems);
  const deductions = sumItems(deductionItems);
  const bonusAmount = Number(bonus || 0);
  const overtimeAmount = Number(overtimePay || 0);
  const netSalary = Number(baseSalary) + allowances + bonusAmount + overtimeAmount - deductions;

  const settings = await getCompanySettings();
  const workingDays = getWorkingDaysInMonth(month, getWeekendDays(settings));
  const dailyRate = round2(getDailyRate(baseSalary, workingDays));

  const payroll = await prisma.payroll.create({
    data: {
      employeeId,
      month,
      baseSalary: Number(baseSalary),
      allowances,
      deductions,
      bonus: bonusAmount,
      overtimePay: overtimeAmount,
      netSalary,
      workingDays,
      dailyRate,
      allowanceItems: allowanceItems || undefined,
      deductionItems: deductionItems || undefined,
      notes,
    },
  });

  res.status(201).json(payroll);
});

const updatePayroll = asyncHandler(async (req, res) => {
  const existing = await prisma.payroll.findUnique({ where: { id: req.params.id } });
  if (!existing) return res.status(404).json({ error: "Payroll record not found" });

  const { baseSalary, allowanceItems, deductionItems, bonus, overtimePay, status, notes } = req.body;

  const newBaseSalary = baseSalary !== undefined ? Number(baseSalary) : Number(existing.baseSalary);
  const newAllowances = allowanceItems !== undefined ? sumItems(allowanceItems) : Number(existing.allowances);
  const newDeductions = deductionItems !== undefined ? sumItems(deductionItems) : Number(existing.deductions);
  const newBonus = bonus !== undefined ? Number(bonus) : Number(existing.bonus);
  const newOvertimePay = overtimePay !== undefined ? Number(overtimePay) : Number(existing.overtimePay);
  const netSalary = newBaseSalary + newAllowances + newBonus + newOvertimePay - newDeductions;

  const payroll = await prisma.payroll.update({
    where: { id: req.params.id },
    data: {
      baseSalary: newBaseSalary,
      allowances: newAllowances,
      deductions: newDeductions,
      bonus: newBonus,
      overtimePay: newOvertimePay,
      netSalary,
      ...(allowanceItems !== undefined && { allowanceItems }),
      ...(deductionItems !== undefined && { deductionItems }),
      ...(status !== undefined && { status }),
      ...(notes !== undefined && { notes }),
    },
  });

  res.json(payroll);
});

const deletePayroll = asyncHandler(async (req, res) => {
  await prisma.payroll.delete({ where: { id: req.params.id } });
  res.status(204).send();
});

// POST /api/payroll/generate-month  { month }
// Creates a DRAFT payroll for every active employee that doesn't already have one for that month.
// Automatically applies the working-day daily rate, absence/permission deductions and overtime pay
// based on that employee's attendance records for the month.
const generateMonth = asyncHandler(async (req, res) => {
  const { month } = req.body;
  if (!month) return res.status(400).json({ error: "Month is required (e.g. 2026-08)" });

  const settings = await getCompanySettings();
  const employees = await prisma.employee.findMany({ where: { status: "ACTIVE" } });
  let created = 0;

  for (const emp of employees) {
    const existing = await prisma.payroll.findUnique({
      where: { employeeId_month: { employeeId: emp.id, month } },
    });
    if (existing) continue;

    const calc = await computeAttendanceComponents(emp, month, settings);
    const baseSalary = Number(emp.baseSalary);
    const netSalary = round2(baseSalary + calc.overtimePay - calc.deductions);

    await prisma.payroll.create({
      data: {
        employeeId: emp.id,
        month,
        baseSalary,
        allowances: 0,
        deductions: calc.deductions,
        bonus: 0,
        overtimePay: calc.overtimePay,
        netSalary,
        workingDays: calc.workingDays,
        dailyRate: calc.dailyRate,
        absenceDays: calc.absenceDays,
        permissionHours: calc.permissionHours,
        overtimeHours: calc.overtimeHours,
        deductionItems: calc.deductionItems,
        status: "DRAFT",
      },
    });
    created++;
  }

  res.status(201).json({ created, totalActiveEmployees: employees.length });
});

// PATCH /api/payroll/:id/recalculate — re-runs the attendance-based calculation
// (working days, daily rate, absence/permission deductions, overtime pay) for an existing
// record, e.g. after attendance was edited. Manual allowance/bonus entries are kept.
const recalculatePayroll = asyncHandler(async (req, res) => {
  const existing = await prisma.payroll.findUnique({
    where: { id: req.params.id },
    include: { employee: true },
  });
  if (!existing) return res.status(404).json({ error: "Payroll record not found" });

  const settings = await getCompanySettings();
  const calc = await computeAttendanceComponents(existing.employee, existing.month, settings);
  const baseSalary = Number(existing.baseSalary);
  const allowances = Number(existing.allowances);
  const bonus = Number(existing.bonus);
  const netSalary = round2(baseSalary + allowances + bonus + calc.overtimePay - calc.deductions);

  const payroll = await prisma.payroll.update({
    where: { id: req.params.id },
    data: {
      deductions: calc.deductions,
      overtimePay: calc.overtimePay,
      netSalary,
      workingDays: calc.workingDays,
      dailyRate: calc.dailyRate,
      absenceDays: calc.absenceDays,
      permissionHours: calc.permissionHours,
      overtimeHours: calc.overtimeHours,
      deductionItems: calc.deductionItems,
    },
  });

  res.json(payroll);
});

module.exports = {
  listPayrolls,
  createPayroll,
  updatePayroll,
  deletePayroll,
  generateMonth,
  recalculatePayroll,
};
