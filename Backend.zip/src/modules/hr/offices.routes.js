const express = require("express");
const { listOffices, createOffice, updateOffice, deleteOffice } = require("./offices.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();
router.use(authenticate, authorize("SUPER_ADMIN", "HR_MANAGER"));

router.get("/", listOffices);
router.post("/", createOffice);
router.patch("/:id", updateOffice);
router.delete("/:id", authorize("SUPER_ADMIN"), deleteOffice);

module.exports = router;
