const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");

const listPermissions = asyncHandler(async (req, res) => {
  const { employeeId, status } = req.query;

  const permissions = await prisma.permission.findMany({
    where: {
      ...(employeeId && { employeeId }),
      ...(status && { status }),
    },
    include: { employee: { select: { id: true, fullName: true } } },
    orderBy: { createdAt: "desc" },
  });

  res.json(permissions);
});

const createPermission = asyncHandler(async (req, res) => {
  const { employeeId, date, fromTime, toTime, reason } = req.body;
  if (!employeeId || !date || !fromTime || !toTime) {
    return res.status(400).json({ error: "Employee, date, from time and to time are required" });
  }

  const permission = await prisma.permission.create({
    data: { employeeId, date: new Date(date), fromTime, toTime, reason },
  });

  res.status(201).json(permission);
});

const updatePermissionStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!["APPROVED", "REJECTED", "PENDING"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  const permission = await prisma.permission.update({
    where: { id: req.params.id },
    data: { status, approvedBy: req.user.id },
  });

  res.json(permission);
});

module.exports = { listPermissions, createPermission, updatePermissionStatus };
