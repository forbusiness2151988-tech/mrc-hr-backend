const express = require("express");
const { listLeaveRequests, createLeaveRequest, updateLeaveStatus } = require("./leaves.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();

router.use(authenticate);

router.get("/", authorize("SUPER_ADMIN", "HR_MANAGER"), listLeaveRequests);
router.post("/", createLeaveRequest); // Any logged-in employee can request leave
router.patch("/:id", authorize("SUPER_ADMIN", "HR_MANAGER"), updateLeaveStatus);

module.exports = router;
