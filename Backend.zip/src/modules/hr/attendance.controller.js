const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");
const { distanceInMeters } = require("../../utils/geo");
const { resolveShift, parseTimeToMinutes } = require("../../utils/payrollCalc");

function todayDateOnly() {
  const d = new Date();
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}

async function getCompanySettings() {
  let settings = await prisma.companySettings.findFirst();
  if (!settings) settings = await prisma.companySettings.create({ data: {} });
  return settings;
}

// GET /api/attendance?employeeId=&month=2026-08
const listAttendance = asyncHandler(async (req, res) => {
  const { employeeId, month } = req.query;

  let dateFilter;
  if (month) {
    const [y, m] = month.split("-").map(Number);
    const start = new Date(Date.UTC(y, m - 1, 1));
    const end = new Date(Date.UTC(y, m, 0, 23, 59, 59));
    dateFilter = { gte: start, lte: end };
  }

  const records = await prisma.attendance.findMany({
    where: {
      ...(employeeId && { employeeId }),
      ...(dateFilter && { date: dateFilter }),
    },
    include: { employee: { select: { id: true, fullName: true } } },
    orderBy: { date: "desc" },
  });

  res.json(records);
});

// POST /api/attendance/check-in  { employeeId, latitude?, longitude?, source? }
// Works from the web UI or a mobile app — same endpoint, same JWT auth.
// When latitude/longitude are sent, the check-in is validated against the
// employee's assigned office geofence (radiusMeters, default 50m).
const checkIn = asyncHandler(async (req, res) => {
  const { employeeId, latitude, longitude, source } = req.body;
  if (!employeeId) return res.status(400).json({ error: "Employee ID is required" });

  const employee = await prisma.employee.findUnique({
    where: { id: employeeId },
    include: { office: true },
  });
  if (!employee) return res.status(404).json({ error: "Employee not found" });

  let distanceM = null;
  let inRange = null;
  if (latitude !== undefined && longitude !== undefined && employee.office) {
    distanceM = distanceInMeters(
      Number(latitude), Number(longitude),
      employee.office.latitude, employee.office.longitude
    );
    inRange = distanceM <= employee.office.radiusMeters;
  }

  const date = todayDateOnly();
  const now = new Date();

  // Late = checked in after the employee's (or company default) shift start time
  const settings = await getCompanySettings();
  const shift = resolveShift(employee, settings);
  const nowMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
  const isLate = nowMinutes > parseTimeToMinutes(shift.start);

  const record = await prisma.attendance.upsert({
    where: { employeeId_date: { employeeId, date } },
    update: {
      checkIn: now,
      status: isLate ? "LATE" : "PRESENT",
      ipAddress: req.ip,
      source: source || "MANUAL",
      checkInLat: latitude !== undefined ? Number(latitude) : undefined,
      checkInLng: longitude !== undefined ? Number(longitude) : undefined,
      checkInDistanceM: distanceM,
      checkInInRange: inRange,
    },
    create: {
      employeeId,
      date,
      checkIn: now,
      status: isLate ? "LATE" : "PRESENT",
      ipAddress: req.ip,
      source: source || "MANUAL",
      checkInLat: latitude !== undefined ? Number(latitude) : null,
      checkInLng: longitude !== undefined ? Number(longitude) : null,
      checkInDistanceM: distanceM,
      checkInInRange: inRange,
    },
  });

  res.status(201).json({
    ...record,
    geofence: employee.office
      ? { officeName: employee.office.name, radiusMeters: employee.office.radiusMeters, distanceM, inRange }
      : null,
  });
});

// POST /api/attendance/check-out  { employeeId, latitude?, longitude? }
const checkOut = asyncHandler(async (req, res) => {
  const { employeeId, latitude, longitude } = req.body;
  if (!employeeId) return res.status(400).json({ error: "Employee ID is required" });

  const employee = await prisma.employee.findUnique({ where: { id: employeeId } });
  if (!employee) return res.status(404).json({ error: "Employee not found" });

  const date = todayDateOnly();
  const existing = await prisma.attendance.findUnique({
    where: { employeeId_date: { employeeId, date } },
  });
  if (!existing) {
    return res.status(400).json({ error: "No check-in recorded for today yet" });
  }

  const settings = await getCompanySettings();
  const shift = resolveShift(employee, settings);
  const checkOutTime = new Date();
  const overtimeMins = existing.checkIn
    ? Math.max(0, Math.round((checkOutTime - existing.checkIn) / 60000) - shift.hours * 60)
    : 0;

  const record = await prisma.attendance.update({
    where: { id: existing.id },
    data: {
      checkOut: checkOutTime,
      overtimeMins,
      checkOutLat: latitude !== undefined ? Number(latitude) : undefined,
      checkOutLng: longitude !== undefined ? Number(longitude) : undefined,
    },
  });

  res.json(record);
});

// POST /api/attendance/bulk-import — upload records from a fingerprint device / CSV file
// body: { rows: [{ employeeId, date, checkIn, checkOut, status }] }
const bulkImport = asyncHandler(async (req, res) => {
  const { rows } = req.body;
  if (!Array.isArray(rows) || rows.length === 0) {
    return res.status(400).json({ error: "No data to import" });
  }

  let imported = 0;
  for (const r of rows) {
    if (!r.employeeId || !r.date) continue;
    const date = new Date(r.date);
    await prisma.attendance.upsert({
      where: { employeeId_date: { employeeId: r.employeeId, date } },
      update: {
        checkIn: r.checkIn ? new Date(r.checkIn) : undefined,
        checkOut: r.checkOut ? new Date(r.checkOut) : undefined,
        status: r.status || "PRESENT",
        source: "CSV_IMPORT",
      },
      create: {
        employeeId: r.employeeId,
        date,
        checkIn: r.checkIn ? new Date(r.checkIn) : null,
        checkOut: r.checkOut ? new Date(r.checkOut) : null,
        status: r.status || "PRESENT",
        source: "CSV_IMPORT",
      },
    });
    imported++;
  }

  res.status(201).json({ imported });
});

// POST /api/attendance/mark-paid-leave  { employeeId, date, reason? }
// Admin/HR manually marks a single day as a Paid Absence/Paid Leave for one employee,
// even if they never checked in/out. No salary deduction applies for that day.
const markPaidLeave = asyncHandler(async (req, res) => {
  const { employeeId, date, reason } = req.body;
  if (!employeeId || !date) {
    return res.status(400).json({ error: "Employee and date are required" });
  }

  const day = new Date(date);
  const record = await prisma.attendance.upsert({
    where: { employeeId_date: { employeeId, date: day } },
    update: { status: "PAID_LEAVE", source: "MANUAL" },
    create: { employeeId, date: day, status: "PAID_LEAVE", source: "MANUAL" },
  });

  res.status(201).json({ ...record, reason: reason || null });
});

// GET /api/attendance/summary?employeeId=&month=2026-08 — monthly summary (present/absent/late/overtime)
const monthlySummary = asyncHandler(async (req, res) => {
  const { employeeId, month } = req.query;
  if (!employeeId || !month) {
    return res.status(400).json({ error: "Employee ID and month are required" });
  }

  const [y, m] = month.split("-").map(Number);
  const start = new Date(Date.UTC(y, m - 1, 1));
  const end = new Date(Date.UTC(y, m, 0, 23, 59, 59));

  const records = await prisma.attendance.findMany({
    where: { employeeId, date: { gte: start, lte: end } },
  });

  const summary = {
    present: records.filter((r) => r.status === "PRESENT").length,
    late: records.filter((r) => r.status === "LATE").length,
    absent: records.filter((r) => r.status === "ABSENT").length,
    onLeave: records.filter((r) => r.status === "ON_LEAVE").length,
    holiday: records.filter((r) => r.status === "HOLIDAY").length,
    paidLeave: records.filter((r) => r.status === "PAID_LEAVE").length,
    totalOvertimeMins: records.reduce((sum, r) => sum + r.overtimeMins, 0),
  };

  res.json(summary);
});

module.exports = { listAttendance, checkIn, checkOut, bulkImport, monthlySummary, markPaidLeave };
