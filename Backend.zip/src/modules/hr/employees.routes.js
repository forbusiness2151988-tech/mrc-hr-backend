const express = require("express");
const {
  listEmployees,
  getEmployee,
  createEmployee,
  updateEmployee,
  deleteEmployee,
} = require("./employees.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();

router.use(authenticate, authorize("SUPER_ADMIN", "HR_MANAGER"));

router.get("/", listEmployees);
router.get("/:id", getEmployee);
router.post("/", createEmployee);
router.patch("/:id", updateEmployee);
router.delete("/:id", authorize("SUPER_ADMIN"), deleteEmployee);

module.exports = router;
