const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");

// There is only ever one CompanySettings row. Create it on first read if missing.
async function getOrCreateSettings() {
  let settings = await prisma.companySettings.findFirst();
  if (!settings) {
    settings = await prisma.companySettings.create({ data: {} });
  }
  return settings;
}

// GET /api/settings
const getSettings = asyncHandler(async (req, res) => {
  const settings = await getOrCreateSettings();
  res.json(settings);
});

// PATCH /api/settings  { shiftStart?, shiftEnd?, weekendDays? }
const updateSettings = asyncHandler(async (req, res) => {
  const { shiftStart, shiftEnd, weekendDays } = req.body;
  const existing = await getOrCreateSettings();

  const settings = await prisma.companySettings.update({
    where: { id: existing.id },
    data: {
      ...(shiftStart !== undefined && { shiftStart }),
      ...(shiftEnd !== undefined && { shiftEnd }),
      ...(weekendDays !== undefined && { weekendDays: weekendDays.map(Number) }),
    },
  });

  res.json(settings);
});

module.exports = { getSettings, updateSettings };
