const express = require("express");
const {
  listPayrolls,
  createPayroll,
  updatePayroll,
  deletePayroll,
  generateMonth,
  recalculatePayroll,
} = require("./payroll.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();
router.use(authenticate, authorize("SUPER_ADMIN", "HR_MANAGER", "ACCOUNTANT"));

router.get("/", listPayrolls);
router.post("/", createPayroll);
router.post("/generate-month", generateMonth);
router.patch("/:id", updatePayroll);
router.patch("/:id/recalculate", recalculatePayroll);
router.delete("/:id", authorize("SUPER_ADMIN"), deletePayroll);

module.exports = router;
