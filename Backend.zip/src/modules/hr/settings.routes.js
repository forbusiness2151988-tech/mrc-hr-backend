const express = require("express");
const { getSettings, updateSettings } = require("./settings.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();
router.use(authenticate);

router.get("/", authorize("SUPER_ADMIN", "HR_MANAGER", "ACCOUNTANT"), getSettings);
router.patch("/", authorize("SUPER_ADMIN", "HR_MANAGER"), updateSettings);

module.exports = router;
