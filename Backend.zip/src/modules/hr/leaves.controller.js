const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");

const listLeaveRequests = asyncHandler(async (req, res) => {
  const { employeeId, status } = req.query;

  const requests = await prisma.leaveRequest.findMany({
    where: {
      ...(employeeId && { employeeId }),
      ...(status && { status }),
    },
    include: { employee: { select: { id: true, fullName: true } } },
    orderBy: { createdAt: "desc" },
  });

  res.json(requests);
});

const createLeaveRequest = asyncHandler(async (req, res) => {
  const { employeeId, type, startDate, endDate, reason } = req.body;
  if (!employeeId || !type || !startDate || !endDate) {
    return res.status(400).json({ error: "Employee, type, start date and end date are required" });
  }

  const request = await prisma.leaveRequest.create({
    data: {
      employeeId,
      type,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      reason,
    },
  });

  res.status(201).json(request);
});

// PATCH /api/leaves/:id — approve or reject (workflow required by the PRD)
const updateLeaveStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!["APPROVED", "REJECTED", "PENDING"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  const request = await prisma.leaveRequest.update({
    where: { id: req.params.id },
    data: { status, approvedBy: req.user.id },
  });

  // If the leave is approved, mark attendance as "ON_LEAVE" for every day of the leave
  if (status === "APPROVED") {
    const days = [];
    let cur = new Date(request.startDate);
    while (cur <= request.endDate) {
      days.push(new Date(cur));
      cur.setUTCDate(cur.getUTCDate() + 1);
    }

    for (const date of days) {
      await prisma.attendance.upsert({
        where: { employeeId_date: { employeeId: request.employeeId, date } },
        update: { status: "ON_LEAVE" },
        create: { employeeId: request.employeeId, date, status: "ON_LEAVE", source: "MANUAL" },
      });
    }
  }

  res.json(request);
});

module.exports = { listLeaveRequests, createLeaveRequest, updateLeaveStatus };
