const prisma = require("../../config/prisma");
const { asyncHandler } = require("../../middleware/errorHandler");

const EXTRA_FIELDS = [
  "employeeCode", "phone", "personalEmail", "address", "nationalId",
  "bankAccountNumber", "emergencyContactName", "emergencyContactPhone",
  "contractType", "status", "officeId", "shiftStart", "shiftEnd",
];

function pickExtraFields(body) {
  const data = {};
  const NULLABLE_WHEN_EMPTY = ["officeId", "shiftStart", "shiftEnd"];
  EXTRA_FIELDS.forEach((key) => {
    if (body[key] === undefined) return;
    data[key] = body[key] === "" && NULLABLE_WHEN_EMPTY.includes(key) ? null : body[key];
  });
  return data;
}

const listEmployees = asyncHandler(async (req, res) => {
  const { search, department, status, officeId } = req.query;

  const employees = await prisma.employee.findMany({
    where: {
      ...(department && { department }),
      ...(status && { status }),
      ...(officeId && { officeId }),
      ...(search && {
        OR: [
          { fullName: { contains: search, mode: "insensitive" } },
          { jobTitle: { contains: search, mode: "insensitive" } },
          { employeeCode: { contains: search, mode: "insensitive" } },
        ],
      }),
    },
    include: { office: { select: { id: true, name: true } } },
    orderBy: { createdAt: "desc" },
  });

  res.json(employees);
});

const getEmployee = asyncHandler(async (req, res) => {
  const employee = await prisma.employee.findUnique({
    where: { id: req.params.id },
    include: {
      office: true,
      attendance: { orderBy: { date: "desc" }, take: 30 },
      leaveRequests: { orderBy: { createdAt: "desc" } },
      permissions: { orderBy: { createdAt: "desc" } },
      payrolls: { orderBy: { month: "desc" } },
    },
  });
  if (!employee) return res.status(404).json({ error: "Employee not found" });
  res.json(employee);
});

const createEmployee = asyncHandler(async (req, res) => {
  const { fullName, jobTitle, department, joiningDate, baseSalary } = req.body;
  if (!fullName || !jobTitle || !joiningDate || baseSalary === undefined) {
    return res.status(400).json({ error: "Name, job title, joining date and salary are required" });
  }

  const employee = await prisma.employee.create({
    data: {
      fullName,
      jobTitle,
      department,
      joiningDate: new Date(joiningDate),
      baseSalary,
      ...pickExtraFields(req.body),
    },
  });

  res.status(201).json(employee);
});

const updateEmployee = asyncHandler(async (req, res) => {
  const { fullName, jobTitle, department, joiningDate, baseSalary, terminationDate } = req.body;

  const employee = await prisma.employee.update({
    where: { id: req.params.id },
    data: {
      ...(fullName !== undefined && { fullName }),
      ...(jobTitle !== undefined && { jobTitle }),
      ...(department !== undefined && { department }),
      ...(joiningDate !== undefined && { joiningDate: new Date(joiningDate) }),
      ...(baseSalary !== undefined && { baseSalary }),
      ...(terminationDate !== undefined && { terminationDate: terminationDate ? new Date(terminationDate) : null }),
      ...pickExtraFields(req.body),
    },
  });

  res.json(employee);
});

const deleteEmployee = asyncHandler(async (req, res) => {
  await prisma.employee.delete({ where: { id: req.params.id } });
  res.status(204).send();
});

module.exports = { listEmployees, getEmployee, createEmployee, updateEmployee, deleteEmployee };
