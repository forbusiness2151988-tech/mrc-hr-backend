const express = require("express");
const { register, login, me } = require("./auth.controller");
const { authenticate } = require("../../middleware/auth");
const { authorize } = require("../../middleware/rbac");

const router = express.Router();

router.post("/login", login);
router.post("/register", authenticate, authorize("SUPER_ADMIN"), register);
router.get("/me", authenticate, me);

module.exports = router;
