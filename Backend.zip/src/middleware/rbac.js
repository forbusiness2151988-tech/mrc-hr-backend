/**
 * Role-based access control.
 * Usage: router.get("/", authenticate, authorize("SUPER_ADMIN", "HR_MANAGER"), handler)
 *
 * SUPER_ADMIN always passes, regardless of the allowed list, since it has
 * full system access.
 */
function authorize(...allowedRoles) {
  return (req, res, next) => {
    const role = req.user?.role;

    if (!role) {
      return res.status(401).json({ error: "Unauthorized: no user" });
    }

    if (role === "SUPER_ADMIN" || allowedRoles.includes(role)) {
      return next();
    }

    return res.status(403).json({ error: "You do not have permission to access this resource" });
  };
}

module.exports = { authorize };
