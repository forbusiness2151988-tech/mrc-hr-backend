/**
 * Centralized error handler — keeps every module's responses consistent
 * so the whole system behaves as one integrated platform, not fragments.
 */
function errorHandler(err, req, res, next) {
  console.error(`[ERROR] ${req.method} ${req.originalUrl} ->`, err);

  // Prisma known errors
  if (err.code === "P2002") {
    return res.status(409).json({ error: "Duplicate entry — this record already exists" });
  }
  if (err.code === "P2025") {
    return res.status(404).json({ error: "Record not found" });
  }

  const status = err.status || 500;
  res.status(status).json({
    error: err.message || "An unexpected server error occurred",
  });
}

// Wraps async route handlers so thrown errors reach errorHandler
// without needing try/catch in every controller.
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { errorHandler, asyncHandler };
