// ============================================================
// Payroll calculation helpers
// Working-day based salary math (default: 22 working days/month,
// excluding Friday + Saturday) + flexible per-employee shift hours.
// ============================================================

const DEFAULT_WEEKEND_DAYS = [5, 6]; // Fri=5, Sat=6 (JS getUTCDay())
const DEFAULT_SHIFT_START = "09:00";
const DEFAULT_SHIFT_END = "17:00";
const OVERTIME_RATE_MULTIPLIER = 1.5; // overtime hour is paid at 1.5x the normal hourly rate

// Total calendar days in a "YYYY-MM" month
function daysInMonth(month) {
  const [y, m] = month.split("-").map(Number);
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

// Returns { start: Date, end: Date } (UTC, inclusive) for a "YYYY-MM" month
function monthRange(month) {
  const [y, m] = month.split("-").map(Number);
  const start = new Date(Date.UTC(y, m - 1, 1));
  const end = new Date(Date.UTC(y, m, 0, 23, 59, 59));
  return { start, end };
}

// Working days in a "YYYY-MM" month = Total Days - (weekend days count)
// e.g. a 31-day month with Fri/Sat weekends → typically ~22 working days
function getWorkingDaysInMonth(month, weekendDays = DEFAULT_WEEKEND_DAYS) {
  const [y, m] = month.split("-").map(Number);
  const total = daysInMonth(month);
  let weekendCount = 0;
  for (let d = 1; d <= total; d++) {
    const day = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
    if (weekendDays.includes(day)) weekendCount++;
  }
  return total - weekendCount;
}

// Daily Rate = Base Salary / Working Days
function getDailyRate(baseSalary, workingDays) {
  if (!workingDays) return 0;
  return Number(baseSalary) / workingDays;
}

function parseTimeToMinutes(time) {
  if (!time) return null;
  const [h, m] = time.split(":").map(Number);
  return h * 60 + (m || 0);
}

// Resolve an employee's effective shift (per-employee override, falling back to company settings)
function resolveShift(employee, settings) {
  const start = employee?.shiftStart || settings?.shiftStart || DEFAULT_SHIFT_START;
  const end = employee?.shiftEnd || settings?.shiftEnd || DEFAULT_SHIFT_END;
  const startMins = parseTimeToMinutes(start);
  let endMins = parseTimeToMinutes(end);
  if (endMins <= startMins) endMins += 24 * 60; // overnight shift safety net
  const hours = (endMins - startMins) / 60;
  return { start, end, hours: hours > 0 ? hours : 8 };
}

// Hourly Rate = Daily Rate / Shift Hours
function getHourlyRate(dailyRate, shiftHours) {
  if (!shiftHours) return 0;
  return dailyRate / shiftHours;
}

function getWeekendDays(settings) {
  return settings?.weekendDays?.length ? settings.weekendDays : DEFAULT_WEEKEND_DAYS;
}

module.exports = {
  DEFAULT_WEEKEND_DAYS,
  DEFAULT_SHIFT_START,
  DEFAULT_SHIFT_END,
  OVERTIME_RATE_MULTIPLIER,
  daysInMonth,
  monthRange,
  getWorkingDaysInMonth,
  getDailyRate,
  getHourlyRate,
  parseTimeToMinutes,
  resolveShift,
  getWeekendDays,
};
